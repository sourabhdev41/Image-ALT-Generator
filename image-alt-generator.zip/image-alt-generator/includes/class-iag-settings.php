<?php
/**
 * Plugin settings management.
 *
 * @package Image_Alt_Generator
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class IAG_Settings
 *
 * Registers and retrieves plugin settings via the WordPress Settings API.
 */
class IAG_Settings {

	/**
	 * Option name used to store settings.
	 *
	 * @var string
	 */
	const OPTION_NAME = 'iag_settings';

	/**
	 * Constructor.
	 */
	public function __construct() {
		add_action( 'admin_init', array( $this, 'register_settings' ) );
	}

	/**
	 * Register settings, sections and fields.
	 */
	public function register_settings() {
		register_setting(
			'iag_settings_group',
			self::OPTION_NAME,
			array(
				'type'              => 'array',
				'sanitize_callback' => array( $this, 'sanitize_settings' ),
				'default'           => array( 'skip_existing_alt' => 1 ),
			)
		);

		add_settings_section(
			'iag_main_section',
			__( 'General Settings', 'image-alt-generator' ),
			'__return_false',
			'iag-settings-page'
		);

		add_settings_field(
			'skip_existing_alt',
			__( 'Skip Images That Already Have ALT Text', 'image-alt-generator' ),
			array( $this, 'render_skip_existing_field' ),
			'iag-settings-page',
			'iag_main_section'
		);
	}

	/**
	 * Sanitize submitted settings values.
	 *
	 * @param array $input Raw input array.
	 * @return array Sanitized settings.
	 */
	public function sanitize_settings( $input ) {
		$sanitized                      = array();
		$sanitized['skip_existing_alt'] = ! empty( $input['skip_existing_alt'] ) ? 1 : 0;

		return $sanitized;
	}

	/**
	 * Render the "skip existing ALT" checkbox field.
	 */
	public function render_skip_existing_field() {
		$settings = self::get_settings();
		$checked  = ! empty( $settings['skip_existing_alt'] );
		?>
		<label for="iag_skip_existing_alt">
			<input
				type="checkbox"
				id="iag_skip_existing_alt"
				name="<?php echo esc_attr( self::OPTION_NAME ); ?>[skip_existing_alt]"
				value="1"
				<?php checked( $checked ); ?>
			/>
			<?php esc_html_e( 'Enabled (default): existing ALT text remains unchanged. Disable to overwrite existing ALT text with generated text.', 'image-alt-generator' ); ?>
		</label>
		<?php
	}

	/**
	 * Retrieve current plugin settings merged with defaults.
	 *
	 * @return array Settings array.
	 */
	public static function get_settings() {
		$defaults = array(
			'skip_existing_alt' => 1,
		);

		$settings = get_option( self::OPTION_NAME, $defaults );

		if ( ! is_array( $settings ) ) {
			$settings = $defaults;
		}

		return wp_parse_args( $settings, $defaults );
	}
}
