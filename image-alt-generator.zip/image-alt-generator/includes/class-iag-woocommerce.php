<?php
/**
 * WooCommerce integration (optional, no hard dependency).
 *
 * @package Image_Alt_Generator
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class IAG_WooCommerce
 *
 * Extends ALT generation to WooCommerce product featured images,
 * gallery images, and variation images — only when WooCommerce
 * is active. Adds no hard dependency on WooCommerce.
 */
class IAG_WooCommerce {

	/**
	 * Constructor.
	 */
	public function __construct() {
		// Only hook in if WooCommerce is active.
		if ( ! $this->is_woocommerce_active() ) {
			return;
		}

		add_action( 'woocommerce_product_set_visibility', array( $this, 'maybe_generate_for_product' ) );
		add_action( 'save_post_product', array( $this, 'maybe_generate_for_product' ) );
		add_action( 'woocommerce_save_product_variation', array( $this, 'maybe_generate_for_variation' ) );
	}

	/**
	 * Check whether WooCommerce plugin is active.
	 *
	 * @return bool
	 */
	private function is_woocommerce_active() {
		return class_exists( 'WooCommerce' );
	}

	/**
	 * Generate ALT text for a product's featured image and gallery images.
	 *
	 * @param int $product_id Product post ID.
	 */
	public function maybe_generate_for_product( $product_id ) {
		if ( ! function_exists( 'wc_get_product' ) ) {
			return;
		}

		$product = wc_get_product( $product_id );

		if ( ! $product ) {
			return;
		}

		// Featured image.
		$thumbnail_id = $product->get_image_id();
		if ( $thumbnail_id ) {
			$this->process_attachment( $thumbnail_id );
		}

		// Gallery images.
		$gallery_ids = $product->get_gallery_image_ids();
		if ( ! empty( $gallery_ids ) ) {
			foreach ( $gallery_ids as $gallery_id ) {
				$this->process_attachment( $gallery_id );
			}
		}
	}

	/**
	 * Generate ALT text for a product variation's image.
	 *
	 * @param int $variation_id Variation post ID.
	 */
	public function maybe_generate_for_variation( $variation_id ) {
		if ( ! function_exists( 'wc_get_product' ) ) {
			return;
		}

		$variation = wc_get_product( $variation_id );

		if ( ! $variation ) {
			return;
		}

		$image_id = $variation->get_image_id();

		if ( $image_id ) {
			$this->process_attachment( $image_id );
		}
	}

	/**
	 * Apply ALT generation rules (respecting skip-existing setting) to an attachment.
	 *
	 * @param int $attachment_id Attachment post ID.
	 */
	private function process_attachment( $attachment_id ) {
		if ( IAG_Generator::should_skip( $attachment_id ) ) {
			return;
		}

		IAG_Generator::update_attachment_alt( $attachment_id );
	}
}
