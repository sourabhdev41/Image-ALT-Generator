<?php
/**
 * Core ALT text generation logic.
 *
 * @package Image_Alt_Generator
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class IAG_Generator
 *
 * Handles converting a filename into clean, human-readable ALT text
 * and applying/scoring it on attachments. Fully offline, no external
 * services or AI models are used.
 */
class IAG_Generator {

	/**
	 * Generate ALT text from an attachment's filename.
	 *
	 * @param int $attachment_id Attachment post ID.
	 * @return string Generated ALT text.
	 */
	public static function generate_from_attachment( $attachment_id ) {
		$file = get_post_meta( $attachment_id, '_wp_attached_file', true );

		if ( empty( $file ) ) {
			$file = get_the_title( $attachment_id );
		}

		$filename = wp_basename( $file );

		return self::generate_from_filename( $filename );
	}

	/**
	 * Convert a raw filename into formatted ALT text.
	 *
	 * @param string $filename Raw filename (with or without extension).
	 * @return string Human-readable, capitalized ALT text.
	 */
	public static function generate_from_filename( $filename ) {
		// Decode URL-encoded characters (e.g. %20).
		$filename = rawurldecode( $filename );

		// Remove the file extension.
		$filename = preg_replace( '/\.[a-zA-Z0-9]{2,5}$/', '', $filename );

		// Remove WordPress generated size suffixes, e.g. -150x150, -768x512.
		$filename = preg_replace( '/-\d+x\d+$/', '', $filename );

		// Replace hyphens and underscores with spaces.
		$filename = str_replace( array( '-', '_' ), ' ', $filename );

		// Remove any remaining non-alphanumeric characters except spaces.
		$filename = preg_replace( '/[^\p{L}\p{N}\s]/u', ' ', $filename );

		// Collapse duplicate/multiple spaces.
		$filename = preg_replace( '/\s+/', ' ', $filename );

		$filename = trim( $filename );

		// Capitalize each word.
		$alt_text = ucwords( strtolower( $filename ) );

		/**
		 * Filter the final generated ALT text before it is returned.
		 *
		 * @param string $alt_text Generated ALT text.
		 * @param string $filename Original filename.
		 */
		return apply_filters( 'iag_generated_alt_text', $alt_text, $filename );
	}

	/**
	 * Update an attachment's ALT text meta with the generated value.
	 *
	 * @param int $attachment_id Attachment post ID.
	 * @return string|false Generated ALT text on success, false if empty.
	 */
	public static function update_attachment_alt( $attachment_id ) {
		$alt_text = self::generate_from_attachment( $attachment_id );

		if ( '' === $alt_text ) {
			return false;
		}

		update_post_meta( $attachment_id, '_wp_attachment_image_alt', sanitize_text_field( $alt_text ) );

		return $alt_text;
	}

	/**
	 * Calculate a simple SEO score for an attachment's ALT text.
	 *
	 * Scoring rule:
	 * - 100 = ALT text is present and not empty.
	 * - 0   = ALT text is missing.
	 *
	 * @param int $attachment_id Attachment post ID.
	 * @return int SEO score (0 or 100).
	 */
	public static function get_seo_score( $attachment_id ) {
		$alt = get_post_meta( $attachment_id, '_wp_attachment_image_alt', true );

		return ( '' !== trim( (string) $alt ) ) ? 100 : 0;
	}

	/**
	 * Determine whether an attachment should be skipped based on settings.
	 *
	 * @param int $attachment_id Attachment post ID.
	 * @return bool True if the attachment should be skipped.
	 */
	public static function should_skip( $attachment_id ) {
		$settings = IAG_Settings::get_settings();

		if ( empty( $settings['skip_existing_alt'] ) ) {
			return false;
		}

		$alt = get_post_meta( $attachment_id, '_wp_attachment_image_alt', true );

		return ( '' !== trim( (string) $alt ) );
	}
}
