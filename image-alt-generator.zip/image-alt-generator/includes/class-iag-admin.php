<?php
/**
 * Admin menu and page rendering.
 *
 * @package Image_Alt_Generator
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class IAG_Admin
 *
 * Builds the "Media → ALT Generator" admin page and enqueues assets.
 */
class IAG_Admin {

	/**
	 * Constructor.
	 */
	public function __construct() {
		add_action( 'admin_menu', array( $this, 'register_admin_page' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_assets' ) );
	}

	/**
	 * Register the submenu page under Media.
	 */
	public function register_admin_page() {
		add_submenu_page(
			'upload.php',
			__( 'ALT Generator', 'image-alt-generator' ),
			__( 'ALT Generator', 'image-alt-generator' ),
			'manage_options',
			'image-alt-generator',
			array( $this, 'render_admin_page' )
		);
	}

	/**
	 * Enqueue admin CSS/JS only on the plugin's own page.
	 *
	 * @param string $hook Current admin page hook suffix.
	 */
	public function enqueue_assets( $hook ) {
		if ( 'media_page_image-alt-generator' !== $hook ) {
			return;
		}

		wp_enqueue_style(
			'iag-admin-style',
			IAG_PLUGIN_URL . 'admin/css/admin.css',
			array(),
			IAG_VERSION
		);

		wp_enqueue_script(
			'iag-admin-script',
			IAG_PLUGIN_URL . 'admin/js/admin.js',
			array( 'jquery' ),
			IAG_VERSION,
			true
		);

		wp_localize_script(
			'iag-admin-script',
			'iagData',
			array(
				'ajaxUrl'  => admin_url( 'admin-ajax.php' ),
				'nonce'    => wp_create_nonce( 'iag_bulk_nonce' ),
				'batchSize' => 20,
				'i18n'     => array(
					'processing' => __( 'Processing…', 'image-alt-generator' ),
					'done'       => __( 'Done!', 'image-alt-generator' ),
					'error'      => __( 'An error occurred. Please try again.', 'image-alt-generator' ),
				),
			)
		);
	}

	/**
	 * Render the main admin page markup.
	 */
	public function render_admin_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$total_images = $this->count_total_images();
		?>
		<div class="wrap iag-wrap">
			<h1><?php esc_html_e( 'Image ALT Generator', 'image-alt-generator' ); ?></h1>
			<p><?php esc_html_e( 'Automatically generate SEO-friendly ALT text for your images based on their filenames. Works fully offline — no AI or external services involved.', 'image-alt-generator' ); ?></p>

			<hr />

			<h2><?php esc_html_e( 'Settings', 'image-alt-generator' ); ?></h2>
			<form method="post" action="options.php">
				<?php
				settings_fields( 'iag_settings_group' );
				do_settings_sections( 'iag-settings-page' );
				submit_button( __( 'Save Settings', 'image-alt-generator' ) );
				?>
			</form>

			<hr />

			<h2><?php esc_html_e( 'Bulk Generate ALT Text', 'image-alt-generator' ); ?></h2>
			<p>
				<?php
				printf(
					/* translators: %d: total number of images found in the Media Library. */
					esc_html__( 'Total images found in Media Library: %d', 'image-alt-generator' ),
					(int) $total_images
				);
				?>
			</p>

			<p>
				<button type="button" class="button button-primary" id="iag-generate-btn">
					<span class="dashicons dashicons-update" aria-hidden="true"></span>
					<?php esc_html_e( 'Generate ALT Text', 'image-alt-generator' ); ?>
				</button>
			</p>

			<div id="iag-progress-wrap" class="iag-progress-wrap" style="display:none;">
				<progress id="iag-progress-bar" max="100" value="0"></progress>
				<p id="iag-progress-text"></p>
			</div>

			<table class="widefat striped iag-summary-table" id="iag-summary-table" style="display:none;">
				<thead>
					<tr>
						<th><?php esc_html_e( 'Total Processed', 'image-alt-generator' ); ?></th>
						<th><?php esc_html_e( 'Updated', 'image-alt-generator' ); ?></th>
						<th><?php esc_html_e( 'Skipped', 'image-alt-generator' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td id="iag-stat-total">0</td>
						<td id="iag-stat-updated">0</td>
						<td id="iag-stat-skipped">0</td>
					</tr>
				</tbody>
			</table>

			<div id="iag-notice-area"></div>

			<hr />

			<h2><?php esc_html_e( 'Image ALT &amp; SEO Score Overview', 'image-alt-generator' ); ?></h2>
			<?php $this->render_image_table(); ?>
		</div>
		<?php
	}

	/**
	 * Count total image attachments (standard library + WooCommerce-related).
	 *
	 * @return int Total image count.
	 */
	private function count_total_images() {
		$query = new WP_Query(
			array(
				'post_type'      => 'attachment',
				'post_status'    => 'inherit',
				'post_mime_type' => 'image',
				'posts_per_page' => 1,
				'fields'         => 'ids',
				'no_found_rows'  => false,
			)
		);

		return (int) $query->found_posts;
	}

	/**
	 * Render a paginated table listing images, current ALT text and SEO score.
	 */
	private function render_image_table() {
		$paged = isset( $_GET['iag_paged'] ) ? max( 1, absint( $_GET['iag_paged'] ) ) : 1; // phpcs:ignore WordPress.Security.NonceVerification.Recommended

		$per_page = 20;

		$query = new WP_Query(
			array(
				'post_type'      => 'attachment',
				'post_status'    => 'inherit',
				'post_mime_type' => 'image',
				'posts_per_page' => $per_page,
				'paged'          => $paged,
				'orderby'        => 'date',
				'order'          => 'DESC',
			)
		);

		if ( ! $query->have_posts() ) {
			echo '<p>' . esc_html__( 'No images found in the Media Library.', 'image-alt-generator' ) . '</p>';
			return;
		}
		?>
		<table class="widefat striped">
			<thead>
				<tr>
					<th><?php esc_html_e( 'Thumbnail', 'image-alt-generator' ); ?></th>
					<th><?php esc_html_e( 'Filename', 'image-alt-generator' ); ?></th>
					<th><?php esc_html_e( 'Current ALT Text', 'image-alt-generator' ); ?></th>
					<th><?php esc_html_e( 'SEO Score', 'image-alt-generator' ); ?></th>
				</tr>
			</thead>
			<tbody>
				<?php while ( $query->have_posts() ) : $query->the_post(); ?>
					<?php
					$attachment_id = get_the_ID();
					$alt_text      = get_post_meta( $attachment_id, '_wp_attachment_image_alt', true );
					$score         = IAG_Generator::get_seo_score( $attachment_id );
					$thumb         = wp_get_attachment_image( $attachment_id, array( 48, 48 ), true );
					$filename      = wp_basename( get_attached_file( $attachment_id ) );
					?>
					<tr>
						<td><?php echo wp_kses_post( $thumb ); ?></td>
						<td><?php echo esc_html( $filename ); ?></td>
						<td><?php echo $alt_text ? esc_html( $alt_text ) : '<em>' . esc_html__( 'Missing', 'image-alt-generator' ) . '</em>'; ?></td>
						<td>
							<span class="iag-score iag-score-<?php echo ( 100 === $score ) ? 'good' : 'bad'; ?>">
								<?php echo esc_html( $score ); ?>
							</span>
						</td>
					</tr>
				<?php endwhile; ?>
			</tbody>
		</table>
		<?php
		$total_pages = (int) $query->max_num_pages;

		if ( $total_pages > 1 ) {
			echo '<div class="tablenav"><div class="tablenav-pages">';
			echo wp_kses_post(
				paginate_links(
					array(
						'base'      => add_query_arg( 'iag_paged', '%#%' ),
						'format'    => '',
						'current'   => $paged,
						'total'     => $total_pages,
						'prev_text' => __( '&laquo; Previous', 'image-alt-generator' ),
						'next_text' => __( 'Next &raquo;', 'image-alt-generator' ),
					)
				)
			);
			echo '</div></div>';
		}

		wp_reset_postdata();
	}
}
