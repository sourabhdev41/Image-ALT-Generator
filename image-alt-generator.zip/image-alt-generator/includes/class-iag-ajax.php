<?php
/**
 * AJAX handlers for bulk ALT text generation.
 *
 * @package Image_Alt_Generator
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class IAG_Ajax
 *
 * Processes images in small batches via AJAX to avoid request timeouts.
 */
class IAG_Ajax {

	/**
	 * Constructor.
	 */
	public function __construct() {
		add_action( 'wp_ajax_iag_process_batch', array( $this, 'process_batch' ) );
	}

	/**
	 * Process one batch of image attachments.
	 *
	 * Expects POST: nonce, offset, batch_size.
	 * Returns JSON: processed, updated, skipped, next_offset, done, total.
	 */
	public function process_batch() {
		check_ajax_referer( 'iag_bulk_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error(
				array( 'message' => __( 'You do not have permission to perform this action.', 'image-alt-generator' ) ),
				403
			);
		}

		$offset     = isset( $_POST['offset'] ) ? absint( $_POST['offset'] ) : 0;
		$batch_size = isset( $_POST['batch_size'] ) ? absint( $_POST['batch_size'] ) : 20;
		$batch_size = $batch_size > 0 ? min( $batch_size, 50 ) : 20;

		$query = new WP_Query(
			array(
				'post_type'      => 'attachment',
				'post_status'    => 'inherit',
				'post_mime_type' => 'image',
				'posts_per_page' => $batch_size,
				'offset'         => $offset,
				'fields'         => 'ids',
				'orderby'        => 'ID',
				'order'          => 'ASC',
			)
		);

		$updated_count = 0;
		$skipped_count = 0;
		$processed     = 0;

		foreach ( $query->posts as $attachment_id ) {
			$processed++;

			if ( IAG_Generator::should_skip( $attachment_id ) ) {
				$skipped_count++;
				continue;
			}

			$result = IAG_Generator::update_attachment_alt( $attachment_id );

			if ( false === $result ) {
				$skipped_count++;
			} else {
				$updated_count++;
			}
		}

		// Total count for progress bar calculation.
		$count_query = new WP_Query(
			array(
				'post_type'      => 'attachment',
				'post_status'    => 'inherit',
				'post_mime_type' => 'image',
				'posts_per_page' => 1,
				'fields'         => 'ids',
			)
		);
		$total = (int) $count_query->found_posts;

		$next_offset = $offset + $batch_size;
		$done        = ( $next_offset >= $total );

		wp_send_json_success(
			array(
				'processed'   => $processed,
				'updated'     => $updated_count,
				'skipped'     => $skipped_count,
				'next_offset' => $next_offset,
				'total'       => $total,
				'done'        => $done,
			)
		);
	}
}
