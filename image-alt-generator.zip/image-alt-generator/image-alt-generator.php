<?php
/**
 * Plugin Name:       Image ALT Generator
 * Plugin URI:        https://wp.nrwone.in
 * Description:       Automatically generates SEO-friendly image ALT text from filenames. Works fully offline, no AI or external APIs. Includes bulk updater, SEO score, and WooCommerce support.
 * Version:           1.0.0
 * Requires PHP:      7.4
 * Requires at least: 6.0
 * Author:            NRW India
 * Author URI:        https://wp.nrwone.in
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       image-alt-generator
 * Domain Path:       /languages
 *
 * @package Image_Alt_Generator
 */

// Block direct access.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Plugin constants.
define( 'IAG_VERSION', '1.0.0' );
define( 'IAG_PLUGIN_FILE', __FILE__ );
define( 'IAG_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'IAG_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'IAG_PLUGIN_BASENAME', plugin_basename( __FILE__ ) );

/**
 * Load required class files.
 */
require_once IAG_PLUGIN_DIR . 'includes/class-iag-generator.php';
require_once IAG_PLUGIN_DIR . 'includes/class-iag-settings.php';
require_once IAG_PLUGIN_DIR . 'includes/class-iag-admin.php';
require_once IAG_PLUGIN_DIR . 'includes/class-iag-ajax.php';
require_once IAG_PLUGIN_DIR . 'includes/class-iag-woocommerce.php';

/**
 * Main plugin bootstrap class.
 */
final class Image_Alt_Generator {

	/**
	 * Singleton instance.
	 *
	 * @var Image_Alt_Generator|null
	 */
	private static $instance = null;

	/**
	 * Get singleton instance.
	 *
	 * @return Image_Alt_Generator
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor.
	 */
	private function __construct() {
		$this->init_hooks();
	}

	/**
	 * Register plugin hooks.
	 */
	private function init_hooks() {
		load_plugin_textdomain( 'image-alt-generator', false, dirname( IAG_PLUGIN_BASENAME ) . '/languages' );

		// Core classes.
		new IAG_Settings();
		new IAG_Admin();
		new IAG_Ajax();

		// WooCommerce support (self-checks for WooCommerce active state).
		new IAG_WooCommerce();

		// Auto-generate ALT text on upload.
		add_action( 'add_attachment', array( $this, 'maybe_generate_on_upload' ) );
	}

	/**
	 * Auto generate ALT text when a new image is uploaded.
	 *
	 * @param int $attachment_id Attachment post ID.
	 */
	public function maybe_generate_on_upload( $attachment_id ) {
		if ( ! wp_attachment_is_image( $attachment_id ) ) {
			return;
		}

		$settings    = IAG_Settings::get_settings();
		$existing    = get_post_meta( $attachment_id, '_wp_attachment_image_alt', true );
		$skip_filled = ! empty( $settings['skip_existing_alt'] );

		if ( $skip_filled && '' !== trim( (string) $existing ) ) {
			return;
		}

		IAG_Generator::update_attachment_alt( $attachment_id );
	}
}

/**
 * Plugin activation hook.
 */
function iag_activate_plugin() {
	$defaults = array(
		'skip_existing_alt' => 1,
	);

	if ( false === get_option( 'iag_settings' ) ) {
		add_option( 'iag_settings', $defaults );
	}
}
register_activation_hook( __FILE__, 'iag_activate_plugin' );

/**
 * Plugin deactivation hook.
 */
function iag_deactivate_plugin() {
	// Intentionally left blank. No scheduled events or transients to clean.
}
register_deactivation_hook( __FILE__, 'iag_deactivate_plugin' );

/**
 * Boot the plugin.
 */
function iag_run_plugin() {
	return Image_Alt_Generator::instance();
}
add_action( 'plugins_loaded', 'iag_run_plugin' );
