/**
 * Admin JavaScript for Image ALT Generator bulk processing.
 *
 * @package Image_Alt_Generator
 */

( function ( $ ) {
	'use strict';

	$( function () {
		var $btn          = $( '#iag-generate-btn' );
		var $progressWrap = $( '#iag-progress-wrap' );
		var $progressBar  = $( '#iag-progress-bar' );
		var $progressText = $( '#iag-progress-text' );
		var $summaryTable = $( '#iag-summary-table' );
		var $statTotal    = $( '#iag-stat-total' );
		var $statUpdated  = $( '#iag-stat-updated' );
		var $statSkipped  = $( '#iag-stat-skipped' );
		var $noticeArea   = $( '#iag-notice-area' );

		var totalProcessed = 0;
		var totalUpdated   = 0;
		var totalSkipped   = 0;

		$btn.on( 'click', function () {
			$btn.prop( 'disabled', true );
			$noticeArea.empty();
			$progressWrap.show();
			$summaryTable.show();

			totalProcessed = 0;
			totalUpdated   = 0;
			totalSkipped   = 0;

			$statTotal.text( '0' );
			$statUpdated.text( '0' );
			$statSkipped.text( '0' );
			$progressBar.val( 0 );
			$progressText.text( iagData.i18n.processing );

			processBatch( 0 );
		} );

		/**
		 * Process a single batch starting at the given offset.
		 *
		 * @param {number} offset Offset of images already processed.
		 */
		function processBatch( offset ) {
			$.ajax( {
				url: iagData.ajaxUrl,
				method: 'POST',
				dataType: 'json',
				data: {
					action: 'iag_process_batch',
					nonce: iagData.nonce,
					offset: offset,
					batch_size: iagData.batchSize
				}
			} ).done( function ( response ) {
				if ( ! response.success ) {
					showError();
					return;
				}

				var data = response.data;

				totalProcessed += data.processed;
				totalUpdated   += data.updated;
				totalSkipped   += data.skipped;

				$statTotal.text( totalProcessed );
				$statUpdated.text( totalUpdated );
				$statSkipped.text( totalSkipped );

				var percent = data.total > 0 ? Math.min( 100, Math.round( ( data.next_offset / data.total ) * 100 ) ) : 100;
				$progressBar.val( percent );
				$progressText.text( percent + '%' );

				if ( data.done ) {
					finishProcessing();
				} else {
					processBatch( data.next_offset );
				}
			} ).fail( function () {
				showError();
			} );
		}

		/**
		 * Display completion notice and reset button state.
		 */
		function finishProcessing() {
			$progressText.text( iagData.i18n.done );
			$btn.prop( 'disabled', false );

			var $notice = $( '<div></div>' )
				.addClass( 'notice notice-success is-dismissible' )
				.append( $( '<p></p>' ).text( iagData.i18n.done ) );

			$noticeArea.append( $notice );
		}

		/**
		 * Display an error notice and reset button state.
		 */
		function showError() {
			$btn.prop( 'disabled', false );
			$progressText.text( iagData.i18n.error );

			var $notice = $( '<div></div>' )
				.addClass( 'notice notice-error is-dismissible' )
				.append( $( '<p></p>' ).text( iagData.i18n.error ) );

			$noticeArea.append( $notice );
		}
	} );
} )( jQuery );
