=== Image ALT Generator ===
Contributors: nrwindia
Tags: alt text, seo, media library, accessibility, woocommerce
Requires at least: 6.0
Tested up to: 6.6
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Automatically generate SEO-friendly image ALT text from filenames. 100% offline, no AI or external APIs.

== Description ==

Image ALT Generator automatically creates clean, human-readable ALT text for your images based on their filenames — entirely offline, with no AI models or third-party services involved.

**Features**

* Auto-generates ALT text from filenames on upload
* Bulk update tool under Media → ALT Generator with AJAX batch processing
* Simple SEO score (100 = ALT text present, 0 = missing)
* Option to skip images that already have ALT text
* WooCommerce support for product, gallery, and variation images (no hard dependency)
* Built entirely with native WordPress admin UI components

== Installation ==

1. Upload the `image-alt-generator` folder to `/wp-content/plugins/`.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. Go to Media → ALT Generator to configure settings and run bulk generation.

== Frequently Asked Questions ==

= Does this plugin use AI? =
No. ALT text is generated purely from the image filename using simple text formatting rules.

= Does it require WooCommerce? =
No. WooCommerce support is automatically enabled only if WooCommerce is detected as active.

== Changelog ==

= 1.0.0 =
* Initial release.
